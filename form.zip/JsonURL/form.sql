CREATE TABLE student_groups (
    id int NOT NULL AUTO_INCREMENT,
    program_session varchar(256),
    student_name VARCHAR(256) NOT NULL default 'none',
    project_title VARCHAR(256),
    supervisor Varchar(256),
PRIMARY KEY (id)
);