from flask import Flask, render_template, request,session,redirect,url_for
from sqlalchemy import create_engine
from sqlalchemy.orm import scoped_session, sessionmaker

from urllib.request import urlopen
import json

app = Flask(__name__)
engine = create_engine('mysql+pymysql://root:123456@localhost:3306/form')

db= scoped_session(sessionmaker(bind=engine))
app.secret_key = 'IAM'

def supervisor():
    # store the URL in url as
    # parameter for urlopen
    url = "https://cms.mlcs.xyz/api/view/teaching_staff/all/"

    # store the response of URL
    response = urlopen(url)

    # storing the JSON response
    # from url in data
    data_json = json.loads(response.read())

    # print the json response
    cs_session = []
    for a in data_json:
        cs_session.append(a['teacher_name'])
    return cs_session


def program_session():
    # store the URL in url as
    # parameter for urlopen
    url = "https://cms.mlcs.xyz/api/view/program_sessions/all/"

    # store the response of URL
    response = urlopen(url)

    # storing the JSON response
    # from url in data
    data_json = json.loads(response.read())

    # print the json response
    cs_session = []
    for a in data_json:
        cs_session.append(a['Session_Title'])
    return cs_session


def student_session(sess):
    # store the URL in url as
    # parameter for urlopen
    url = "https://cms.mlcs.xyz/api/view/students_of/" + sess + "/all/"

    # store the response of URL
    response = urlopen(url)

    # storing the JSON response
    # from url in data
    data_json = json.loads(response.read())

    # print the json response
    student_name = []
    for a in data_json:
        student_name.append(a['student_name'])
    return student_name

@app.route("/", methods=['GET','POST'])
def index():
    cs_session = program_session()
    if request.form.get("btn") == "next":
        sess = request.form.get("program")
        session['session'] = sess
        return redirect(url_for('student'))
    return render_template("index.html", cs_session=cs_session)


@app.route("/session", methods=['GET','POST'])
def student():
    student = student_session(session['session'])
    if request.form.get("btn") == "next":
        students= request.form.get("student")
        session['student_name'] = students
        return redirect(url_for('form'))

    return render_template("student.html", student=student)


@app.route('/form', methods=['GET','POST'])
def form():
    teacher = supervisor()
    if request.method == 'POST':
        program = request.form['session']
        name = request.form['name']
        title = request.form['title']
        select_supervisor = request.form['select_supervisor']
        db.execute("INSERT INTO student_groups(program_session, student_name, project_title, supervisor) VALUES (:program_session, :student_name, :project_title, :supervisor)",
        {"program_session":program, "student_name":name, "project_title":title, "supervisor":select_supervisor})

    db.commit()

    return render_template('advanced.html', teacher=teacher)


if __name__ == "__main__":
    app.run(debug=True)
